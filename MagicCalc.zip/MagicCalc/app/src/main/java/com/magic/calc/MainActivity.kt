package com.magic.calc

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * A normal-looking calculator with a hidden magic mode.
 *
 *  - VOLUME DOWN        : toggles between NORMAL and PERFORMANCE mode (haptic cue only).
 *  - "=" in PERFORMANCE : shows the saved prediction, whatever was typed.
 *  - Hold "=" for 3 s   : prediction entry. Type the number, tap "=" to save.
 *                         (Saving an empty entry cancels and keeps the old prediction.)
 *
 * Haptic cues (so nothing visible ever gives the secret away):
 *   performance ON  = two short buzzes     performance OFF = one buzz
 *   entry started   = one long buzz        prediction saved = three quick buzzes
 */
class MainActivity : Activity() {

    companion object {
        private const val PREFS = "calc_state"
        private const val KEY_PREDICTION = "p"
        private const val HOLD_MS = 3000L
        private const val HAPTICS = true      // set false to disable all vibration cues
        private const val MAX_LEN = 30
        private const val OPS = "+−×÷"
    }

    private val rows = listOf(
        listOf("C", "⌫", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "−"),
        listOf("1", "2", "3", "+"),
        listOf("0", ".", "=")
    )

    private lateinit var displayView: TextView
    private lateinit var historyView: TextView
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private val expr = StringBuilder()
    private var history = ""
    private var justEvaluated = false
    private var performance = false   // never persisted: the app always starts in normal mode
    private var entering = false
    private var holdFired = false

    private val holdRunnable = Runnable {
        holdFired = true
        startEntry()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        displayView = findViewById(R.id.display)
        historyView = findViewById(R.id.history)
        buildKeypad(findViewById(R.id.keypad))
        refresh()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(holdRunnable)
    }

    // ---- Volume down: toggle performance mode, and swallow the key so volume never changes ----

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) togglePerformance()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun togglePerformance() {
        performance = !performance
        buzz(if (performance) longArrayOf(0, 45, 90, 45) else longArrayOf(0, 70))
    }

    // ---- Keypad ----

    private fun buildKeypad(container: LinearLayout) {
        for (row in rows) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f)
            }
            for (key in row) rowLayout.addView(makeButton(key, if (key == "0") 2f else 1f))
            container.addView(rowLayout)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeButton(key: String, weight: Float): Button {
        val isOp = key == "=" || OPS.contains(key)
        val isFn = key == "C" || key == "⌫" || key == "%"
        val fill = when {
            isOp -> 0xFFFF9F0A.toInt()
            isFn -> 0xFFA5A5A5.toInt()
            else -> 0xFF333333.toInt()
        }
        val shape = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(30f)
        }
        val margin = dp(5f).toInt()

        return Button(this).apply {
            text = key
            textSize = 30f
            isAllCaps = false
            setTextColor(if (isFn) Color.BLACK else Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            stateListAnimator = null
            background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), shape, null)
            layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, weight).apply {
                setMargins(margin, margin, margin, margin)
            }

            if (key == "=") {
                setOnTouchListener { v, ev ->
                    when (ev.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            v.isPressed = true
                            holdFired = false
                            if (!entering) handler.postDelayed(holdRunnable, HOLD_MS)
                        }
                        MotionEvent.ACTION_UP -> {
                            v.isPressed = false
                            handler.removeCallbacks(holdRunnable)
                            val inside = ev.x >= 0 && ev.x <= v.width && ev.y >= 0 && ev.y <= v.height
                            if (!holdFired && inside) onEquals()
                            holdFired = false
                        }
                        MotionEvent.ACTION_CANCEL -> {
                            v.isPressed = false
                            handler.removeCallbacks(holdRunnable)
                        }
                    }
                    true
                }
            } else {
                setOnClickListener { press(key) }
            }
        }
    }

    // ---- Calculator logic ----

    private fun startFreshIfNeeded() {
        if (justEvaluated) {
            expr.clear()
            history = ""
            justEvaluated = false
        }
    }

    private fun press(key: String) {
        val isDigit = key.length == 1 && key[0].isDigit()
        val isOp = key.length == 1 && OPS.contains(key)
        if ((isOp || key == "%") && expr.toString() == "Error") return

        when {
            key == "C" -> {
                expr.clear(); history = ""; justEvaluated = false
            }
            key == "⌫" -> {
                if (justEvaluated) {
                    expr.clear(); history = ""; justEvaluated = false
                } else if (expr.isNotEmpty()) {
                    expr.deleteCharAt(expr.length - 1)
                }
            }
            isDigit -> {
                startFreshIfNeeded()
                if (expr.length < MAX_LEN) expr.append(key)
            }
            key == "." -> {
                startFreshIfNeeded()
                if (expr.length < MAX_LEN) {
                    var i = expr.length - 1
                    while (i >= 0 && (expr[i].isDigit() || expr[i] == '.')) i--
                    val current = expr.substring(i + 1)
                    if (!current.contains('.')) expr.append(if (current.isEmpty()) "0." else ".")
                }
            }
            entering -> return   // while entering a prediction only digits, ".", C and ⌫ work
            isOp -> {
                if (justEvaluated) { history = ""; justEvaluated = false }
                if (expr.isEmpty()) {
                    if (key == "−") expr.append(key)
                } else {
                    val last = expr.last()
                    if (OPS.contains(last)) {
                        if (expr.length > 1) expr.setCharAt(expr.length - 1, key[0])
                    } else if (expr.length < MAX_LEN) {
                        expr.append(key)
                    }
                }
            }
            key == "%" -> {
                if (expr.isNotEmpty() && (expr.last().isDigit() || expr.last() == '%') && expr.length < MAX_LEN) {
                    justEvaluated = false
                    expr.append('%')
                }
            }
        }
        refresh()
    }

    private fun onEquals() {
        if (entering) {
            savePrediction()
            return
        }
        if (expr.isEmpty()) return

        val shown = expr.toString()
        val prediction = prefs.getString(KEY_PREDICTION, null)

        if (performance && prediction != null) {
            // THE REVEAL: whatever was typed, show the prediction.
            history = "$shown ="
            expr.clear()
            expr.append(prediction)
            justEvaluated = true
            refresh()
            return
        }

        // Normal behaviour
        var e = shown
        while (e.isNotEmpty() && OPS.contains(e.last())) e = e.dropLast(1)
        try {
            val result = Evaluator.format(Evaluator.evaluate(e))
            history = "$shown ="
            expr.clear()
            expr.append(if (result == "Error") "Error" else result)
        } catch (ex: Exception) {
            history = ""
            expr.clear()
            expr.append("Error")
        }
        justEvaluated = true
        refresh()
    }

    // ---- Prediction entry (hold "=" for 3 seconds) ----

    private fun startEntry() {
        entering = true
        expr.clear()
        history = ""
        justEvaluated = false
        refresh()
        buzz(longArrayOf(0, 250))
    }

    private fun savePrediction() {
        val value = expr.toString().trimEnd('.')
        if (value.isNotEmpty()) {
            prefs.edit().putString(KEY_PREDICTION, value).apply()
        }
        entering = false
        expr.clear()
        history = ""
        justEvaluated = false
        refresh()
        buzz(longArrayOf(0, 60, 70, 60, 70, 60))
    }

    // ---- Helpers ----

    private fun refresh() {
        displayView.text = if (expr.isEmpty()) "0" else expr.toString()
        historyView.text = history
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    @Suppress("DEPRECATION")
    private fun buzz(pattern: LongArray) {
        if (!HAPTICS) return
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }
}
