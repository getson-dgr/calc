package com.magic.calc

import java.math.BigDecimal
import java.math.RoundingMode

/** Small recursive-descent expression evaluator: + - × ÷ and postfix %. */
object Evaluator {

    fun evaluate(input: String): Double {
        val normalized = input
            .replace('×', '*')
            .replace('÷', '/')
            .replace('−', '-')
            .replace(" ", "")
        val parser = Parser(normalized)
        val value = parser.parseExpression()
        if (parser.pos != normalized.length) throw IllegalArgumentException("Unexpected input")
        return value
    }

    fun format(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "Error"
        val bd = BigDecimal(value).setScale(10, RoundingMode.HALF_UP).stripTrailingZeros()
        return if (bd.scale() <= 0) bd.toBigInteger().toString() else bd.toPlainString()
    }

    private class Parser(val s: String) {
        var pos = 0

        fun parseExpression(): Double {
            var v = parseTerm()
            while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                val op = s[pos++]
                val r = parseTerm()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun parseTerm(): Double {
            var v = parseUnary()
            while (pos < s.length && (s[pos] == '*' || s[pos] == '/')) {
                val op = s[pos++]
                val r = parseUnary()
                if (op == '*') {
                    v *= r
                } else {
                    if (r == 0.0) throw ArithmeticException("Divide by zero")
                    v /= r
                }
            }
            return v
        }

        private fun parseUnary(): Double {
            if (pos < s.length && s[pos] == '-') {
                pos++
                return -parseUnary()
            }
            if (pos < s.length && s[pos] == '+') {
                pos++
                return parseUnary()
            }
            return parsePostfix()
        }

        private fun parsePostfix(): Double {
            var v = parseNumber()
            while (pos < s.length && s[pos] == '%') {
                pos++
                v /= 100.0
            }
            return v
        }

        private fun parseNumber(): Double {
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Number expected")
            return s.substring(start, pos).toDouble()
        }
    }
}
