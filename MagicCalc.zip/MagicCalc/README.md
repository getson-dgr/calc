# MagicCalc – prediction reveal calculator (Android)

Looks and works like a normal calculator. Secretly it can reveal a number you saved in advance.

## How to use it

| Action | What happens |
|---|---|
| Open the app | Normal calculator (always starts in normal mode) |
| Press **Volume Down** | Toggles **performance mode** on/off. The volume never changes. |
| **Hold "=" for 3 seconds** | Prediction entry opens (one long buzz). |
| Type the number, tap **"="** | Prediction saved (three quick buzzes). Display clears. |
| Performance mode on + spectator types anything + **"="** | Shows your saved prediction instead of the real answer. |
| Performance mode off | Everything calculates normally. |

Notes:
- Saving an empty entry cancels, so the old prediction is kept.
- If no prediction has been saved yet, "=" always calculates normally, even in performance mode.
- Vibration cues are the only feedback (nothing visible gives the secret away):
  - performance ON = two short buzzes, performance OFF = one buzz
  - entry started = one long buzz, saved = three quick buzzes
- To turn the buzzes off, set `HAPTICS = false` at the top of `MainActivity.kt`.

## Build

1. Open this folder in **Android Studio** (Gradle sync will download everything).
2. Plug in your phone (USB debugging on) and press **Run**, or use **Build > Build APK(s)**.
3. If Android Studio offers to upgrade the Android Gradle Plugin, accept it.

Package: `com.magic.calc`, minSdk 26 (Android 8.0+), portrait only.
App name shown on the phone: "Calculator" (change in `res/values/strings.xml`).
